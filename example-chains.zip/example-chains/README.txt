# Example telephone chains

**Explanation of the sound files in this directory.**

The filenames describe what sounds are played. "first-imitation-{category}"
means the file is the first imitation of a chain in a particular category.
Filenames beginning with "first-last" contain the first and last imitation
in a chain. Full chains contain all imitations in the chain.

The "full-chain-lobster" chain is included as a funny example, but note that
chains like these were discarded because the imitator clearly said something in
English, which was against the rules of the experiment.
